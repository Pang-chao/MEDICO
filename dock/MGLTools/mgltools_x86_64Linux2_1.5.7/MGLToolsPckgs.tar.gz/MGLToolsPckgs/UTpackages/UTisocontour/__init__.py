#this is __init__.py of isocontour module
from isocontour import *

__MGLTOOLSVersion__ = '1.3alpha2'
