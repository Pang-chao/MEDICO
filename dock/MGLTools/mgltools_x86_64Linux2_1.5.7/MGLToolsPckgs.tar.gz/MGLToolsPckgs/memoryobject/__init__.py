##/******************************************************************************
##**                                                                           **
##** MemoryObject V1.0                                                         **
##**                                                                           **
##** Copyright: (C) 2007 Michel F. Sanner and TSRI                             **
##**                                                                           **
##** ALL RIGHTS RESERVED.                                                      **
##**                                                                           **
##**                                                                           **
##**___________________________________________________________________________**
##**                                                                           **
##**   Authors: Michel F. Sanner                               Jan. 2007       **
##**                                                                           **
##**   e-mail: sanner@scripps.edu                                              **
##**   www:    http://www.scripps.edu/~sanner                                  **
##**                                                                           **
##**            The Scripps Research Institute                                 **
##**            Department of Molecular Biology, MB5                           **
##**            10666 North Torrey Pines Road                                  **
##**            La Jolla, CA 92037.                                            **
##**                                                                           **
##**      Date: 25/01/07                                                       **
##**__________________________________________________________________________ **/

