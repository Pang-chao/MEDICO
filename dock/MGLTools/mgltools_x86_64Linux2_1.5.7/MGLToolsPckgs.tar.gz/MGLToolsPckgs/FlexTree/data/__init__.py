packageContainsVFCommands = 1
#__MGLTOOLSVersion__ = '1-4alpha3'
