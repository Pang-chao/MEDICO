packageContainsVFCommands = 1
#__MGLTOOLSVersion__ = '1-4alpha3'
CRITICAL_DEPENDENCIES =['MolKit', 'numpy','geomutils' , 'memoryobject', 'cAutoDock']
NONCRITICAL_DEPENDENCIES =['Pmv', 'AutoDockFR', 'ViewerFramework', 'mglutil', 'Pmw',  'geomutils', 'DejaVu', 'opengltk', 'binaries', 'mslib', 'sff', 'AutoDockTools', 'NetworkEditor', 'Vision', 'symserv']
