#ifndef _epmv_update_H_
#define _epmv_update_H_

enum
{
	txtCode = 400
};

#endif