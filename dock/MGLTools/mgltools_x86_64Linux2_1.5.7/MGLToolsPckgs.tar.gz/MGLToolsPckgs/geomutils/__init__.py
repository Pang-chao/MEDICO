
__MGLTOOLSVersion__ = '1-4alpha3'
CRITICAL_DEPENDENCIES = ['mglutil' , 'Numpy']
NONCRITICAL_DEPENDENCIES = []

