#########################################################################
#
# Date: Nov. 2001  Author: Michel Sanner
#
# Copyright: Michel Sanner and TSRI
#
#########################################################################

CRITICAL_DEPENDENCIES = ['Pmw', 'mglutil','numpy']
NONCRITICAL_DEPENDENCIES = ['idlelib', 'DejaVu','Vision','Support', 'PIL',
                            'cairo']
