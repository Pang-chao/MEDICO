# This package handles splash screen creation and user registration
#
# $Author: sargis $
# $Header: /mnt/raid/services/cvs/python/packages/share1.5/mglutil/splashregister/__init__.py,v 1.1 2006/05/10 20:25:31 sargis Exp $
# $Date: 2006/05/10 20:25:31 $
# $Id: __init__.py,v 1.1 2006/05/10 20:25:31 sargis Exp $
