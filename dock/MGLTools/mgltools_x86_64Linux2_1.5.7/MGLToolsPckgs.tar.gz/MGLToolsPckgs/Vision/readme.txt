tutorial and examples must be downloaded separately from:

http://mgltools.scripps.edu/downloads

in the section Supplementary Material
